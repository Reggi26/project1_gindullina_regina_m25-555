# project1_gindullina_regina_m25-555
Домашняя работа №1, Гиндуллина Р.И.
